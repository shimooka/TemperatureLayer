# Keep the app classes
-keep class jp.doyouphp.android.temperaturelayer.** { *; }
