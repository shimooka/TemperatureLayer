package jp.doyouphp.android.temperaturelayer.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import jp.doyouphp.android.temperaturelayer.config.TemperatureLayerConfig;
import jp.doyouphp.android.temperaturelayer.service.TemperatureLayerService;

/**
 * Starts the temperature overlay service on device boot if enabled in settings.
 */
public class TemperatureLayerReceiver extends BroadcastReceiver {

    private static final String TAG = "TemperatureLayer";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;

        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            TemperatureLayerConfig config = new TemperatureLayerConfig(context);
            if (config.isStartOnBoot()) {
                Log.i(TAG, "Starting TemperatureLayerService on boot");
                Intent serviceIntent = new Intent(context, TemperatureLayerService.class);
                context.startForegroundService(serviceIntent);
            }
        }
    }
}
