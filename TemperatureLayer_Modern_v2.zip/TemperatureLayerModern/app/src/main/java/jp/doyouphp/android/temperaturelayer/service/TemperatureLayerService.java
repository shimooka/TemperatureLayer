package jp.doyouphp.android.temperaturelayer.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import jp.doyouphp.android.temperaturelayer.R;
import jp.doyouphp.android.temperaturelayer.TemperatureLayerActivity;
import jp.doyouphp.android.temperaturelayer.config.TemperatureLayerConfig;

/**
 * Modernized overlay service for battery temperature.
 * Supports Android 8+ (minSdk 26) and works on Android 13/14.
 */
public class TemperatureLayerService extends Service {

    public static final String TAG = "TemperatureLayer";
    public static final String KEY_EDIT_MODE = "EDIT_MODE";
    private static final String CHANNEL_ID = "temperature_layer_channel";
    private static final int NOTIFICATION_ID = 1001;

    private View mOverlayView;
    private WindowManager mWindowManager;
    private WindowManager.LayoutParams mLayoutParams;
    private TextView mTemperatureText;
    private TemperatureLayerConfig mConfig;
    private boolean mIsEditMode = false;

    private final BroadcastReceiver mBatteryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())) {
                int temperature = intent.getIntExtra("temperature", 0);
                updateTemperature(temperature);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        mConfig = new TemperatureLayerConfig(this);
        createNotificationChannel();
        mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        mIsEditMode = intent != null && intent.getBooleanExtra(KEY_EDIT_MODE, false);

        // Start as foreground service
        startForeground(NOTIFICATION_ID, buildNotification(
                getString(R.string.notification_ticker),
                getString(R.string.notification_content)));

        if (!Settings.canDrawOverlays(this)) {
            Log.w(TAG, "Overlay permission not granted");
            stopSelf();
            return START_NOT_STICKY;
        }

        setupOverlay();
        registerBatteryReceiver();

        return START_STICKY;
    }

    private void setupOverlay() {
        if (mOverlayView != null) {
            try {
                mWindowManager.removeView(mOverlayView);
            } catch (Exception ignored) {}
        }

        mOverlayView = LayoutInflater.from(this).inflate(R.layout.overlay, null);
        mTemperatureText = mOverlayView.findViewById(R.id.currentTemperature);

        mTemperatureText.setTextSize(mConfig.getTextSize());
        int color = mIsEditMode ? Color.RED : mConfig.getColor();
        mTemperatureText.setTextColor(color);

        mLayoutParams = createLayoutParams(mIsEditMode);
        mLayoutParams.x = mConfig.getX();
        mLayoutParams.y = mConfig.getY();

        if (mIsEditMode) {
            mOverlayView.setOnTouchListener(mTouchListener);
        }

        try {
            mWindowManager.addView(mOverlayView, mLayoutParams);
        } catch (Exception e) {
            Log.e(TAG, "Failed to add overlay view", e);
            stopSelf();
        }
    }

    private WindowManager.LayoutParams createLayoutParams(boolean editMode) {
        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);

        if (!editMode) {
            params.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        }

        params.gravity = Gravity.TOP | Gravity.START;
        return params;
    }

    private final View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        private int lastX, lastY;
        private int clickCount = 0;
        private long startTime;
        private static final int MAX_DURATION = 750;
        private static final int REQUIRED_TAP_COUNT = 2;

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = (int) event.getRawX();
                    lastY = (int) event.getRawY();
                    startTime = System.currentTimeMillis();
                    clickCount++;
                    return true;

                case MotionEvent.ACTION_MOVE:
                    int dx = (int) event.getRawX() - lastX;
                    int dy = (int) event.getRawY() - lastY;
                    lastX = (int) event.getRawX();
                    lastY = (int) event.getRawY();

                    mLayoutParams.x += dx;
                    mLayoutParams.y += dy;
                    mConfig.setX(mLayoutParams.x);
                    mConfig.setY(mLayoutParams.y);

                    try {
                        mWindowManager.updateViewLayout(mOverlayView, mLayoutParams);
                    } catch (Exception e) {
                        Log.w(TAG, "updateViewLayout failed", e);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    long duration = System.currentTimeMillis() - startTime;
                    if (clickCount >= REQUIRED_TAP_COUNT && duration <= MAX_DURATION) {
                        exitEditMode();
                        clickCount = 0;
                    }
                    return true;

                case MotionEvent.ACTION_POINTER_UP:
                    if (event.getPointerCount() == 2) {
                        exitEditMode();
                    }
                    return true;
            }
            return false;
        }
    };

    private void exitEditMode() {
        Intent intent = new Intent(this, TemperatureLayerService.class);
        stopService(intent);
        startService(intent);
        Toast.makeText(this, R.string.exit_edit_mode, Toast.LENGTH_SHORT).show();
    }

    private void updateTemperature(int temperatureRaw) {
        if (mTemperatureText == null) return;

        String text = getTemperatureString(temperatureRaw);
        if (text.equals(mTemperatureText.getText().toString())) return;

        mTemperatureText.setText(text);

        if (mConfig.isNotify()) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIFICATION_ID, buildNotification(
                    getString(R.string.notification_message, text), text));
        }

        if (temperatureRaw >= mConfig.getTemperatureThreshold()) {
            if (mConfig.withVibration()) {
                vibrate();
            }
        }
    }

    private String getTemperatureString(int temperatureRaw) {
        double value = temperatureRaw / 10.0;
        if (!mConfig.useCelsius()) {
            value = value * 9.0 / 5.0 + 32.0;
        }
        return String.format("%.1f°%s", value, mConfig.getTemperatureUnit());
    }

    private void vibrate() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            VibratorManager vm = (VibratorManager) getSystemService(VIBRATOR_MANAGER_SERVICE);
            if (vm != null) {
                Vibrator v = vm.getDefaultVibrator();
                v.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE));
            }
        } else {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                v.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE));
            }
        }
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_LOW);
        channel.setDescription(getString(R.string.channel_description));
        channel.setShowBadge(false);

        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(channel);
    }

    private Notification buildNotification(String title, String content) {
        Intent intent = new Intent(this, TemperatureLayerActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(content)
                .setSmallIcon(R.drawable.ic_stat_name)
                .setContentIntent(pi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .build();
    }

    private void registerBatteryReceiver() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(mBatteryReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
    }

    @Override
    public void onDestroy() {
        try {
            unregisterReceiver(mBatteryReceiver);
        } catch (Exception ignored) {}

        if (mWindowManager != null && mOverlayView != null) {
            try {
                mWindowManager.removeView(mOverlayView);
            } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
