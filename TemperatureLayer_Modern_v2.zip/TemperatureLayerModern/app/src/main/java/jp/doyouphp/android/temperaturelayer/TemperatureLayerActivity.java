package jp.doyouphp.android.temperaturelayer;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import jp.doyouphp.android.temperaturelayer.service.TemperatureLayerService;

/**
 * Main activity - Start / Stop the overlay service and request overlay permission.
 */
public class TemperatureLayerActivity extends AppCompatActivity {

    private static final int REQUEST_OVERLAY_PERMISSION = 1001;

    private Button mStartButton;
    private Button mStopButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperature_layer);

        mStartButton = findViewById(R.id.StartButton);
        mStopButton = findViewById(R.id.StopButton);

        mStartButton.setOnClickListener(v -> startOverlayService());
        mStopButton.setOnClickListener(v -> stopOverlayService());

        findViewById(R.id.settingsButton).setOnClickListener(v ->
                startActivity(new Intent(this, SettingActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateButtons();
    }

    private void startOverlayService() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission();
            return;
        }
        Intent intent = new Intent(this, TemperatureLayerService.class);
        startForegroundService(intent);
        updateButtons();
        Toast.makeText(this, R.string.service_started, Toast.LENGTH_SHORT).show();
    }

    private void stopOverlayService() {
        stopService(new Intent(this, TemperatureLayerService.class));
        updateButtons();
        Toast.makeText(this, R.string.service_stopped, Toast.LENGTH_SHORT).show();
    }

    private void requestOverlayPermission() {
        Intent intent = new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
        Toast.makeText(this, R.string.need_overlay_permission, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            if (Settings.canDrawOverlays(this)) {
                startOverlayService();
            } else {
                Toast.makeText(this, R.string.overlay_permission_denied, Toast.LENGTH_LONG).show();
            }
        }
    }

    private void updateButtons() {
        // Simple heuristic: we cannot easily check if service is running on modern Android
        // without additional tracking. Buttons remain enabled.
        mStartButton.setEnabled(true);
        mStopButton.setEnabled(true);
    }
}
