package jp.doyouphp.android.temperaturelayer.config;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;

import jp.doyouphp.android.temperaturelayer.R;

/**
 * Configuration helper for Temperature Layer.
 * Modernized for AndroidX Preference and current Android versions.
 */
public final class TemperatureLayerConfig {

    public static final String KEY_START_ON_BOOT = "key_start_on_boot";
    public static final String KEY_NOTIFICATION = "key_notification";
    public static final String KEY_TEMPERATURE_UNIT = "key_temperature_unit";
    public static final String KEY_TEXT_SIZE = "key_text_size";
    public static final String KEY_COLOR = "key_color";
    public static final String KEY_X = "key_x";
    public static final String KEY_Y = "key_y";
    public static final String KEY_TEMPERATURE_THRESHOLD = "key_temperature_threshold";
    public static final String KEY_VIBRATION = "key_vibration";
    public static final String KEY_SOUND = "key_sound";

    private final Context mContext;
    private final SharedPreferences mPrefs;

    public TemperatureLayerConfig(Context context) {
        mContext = context.getApplicationContext();
        mPrefs = PreferenceManager.getDefaultSharedPreferences(mContext);
        ensureDefaults();
    }

    private void ensureDefaults() {
        if (!mPrefs.contains(KEY_TEMPERATURE_UNIT)) {
            mPrefs.edit()
                    .putBoolean(KEY_START_ON_BOOT, false)
                    .putBoolean(KEY_NOTIFICATION, false)
                    .putString(KEY_TEMPERATURE_UNIT, "C")
                    .putInt(KEY_TEXT_SIZE, 14)
                    .putInt(KEY_COLOR, Color.WHITE)
                    .putInt(KEY_X, 0)
                    .putInt(KEY_Y, 100)
                    .putInt(KEY_TEMPERATURE_THRESHOLD, 450) // 45.0°C
                    .putBoolean(KEY_VIBRATION, true)
                    .putBoolean(KEY_SOUND, false)
                    .apply();
        }
    }

    public Context getContext() {
        return mContext;
    }

    public boolean isStartOnBoot() {
        return mPrefs.getBoolean(KEY_START_ON_BOOT, false);
    }

    public boolean isNotify() {
        return mPrefs.getBoolean(KEY_NOTIFICATION, false);
    }

    public boolean useCelsius() {
        return "C".equals(mPrefs.getString(KEY_TEMPERATURE_UNIT, "C"));
    }

    public String getTemperatureUnit() {
        return useCelsius() ? "C" : "F";
    }

    public int getTextSize() {
        return mPrefs.getInt(KEY_TEXT_SIZE, 14);
    }

    public int getColor() {
        return mPrefs.getInt(KEY_COLOR, Color.WHITE);
    }

    public int getX() {
        return mPrefs.getInt(KEY_X, 0);
    }

    public int getY() {
        return mPrefs.getInt(KEY_Y, 100);
    }

    public void setX(int x) {
        mPrefs.edit().putInt(KEY_X, x).apply();
    }

    public void setY(int y) {
        mPrefs.edit().putInt(KEY_Y, y).apply();
    }

    public int getTemperatureThreshold() {
        return mPrefs.getInt(KEY_TEMPERATURE_THRESHOLD, 450);
    }

    public boolean withVibration() {
        return mPrefs.getBoolean(KEY_VIBRATION, true);
    }

    public boolean withSound() {
        return mPrefs.getBoolean(KEY_SOUND, false);
    }
}
