# Temperature Layer (Modernized)

Android application that displays battery temperature as a transparent overlay.

This is a modernized version of the original [TemperatureLayer](https://github.com/shimooka/TemperatureLayer) by Hideyuki SHIMOOKA.

## Changes from original (v1.0.5 → v2.0.0)

- Migrated from Eclipse/Ant to Android Studio + Gradle
- Target SDK 34 / Min SDK 26 (Android 8.0+)
- Overlay uses `TYPE_APPLICATION_OVERLAY` (required for Android 8+)
- Proper overlay permission request flow
- Foreground Service + Notification Channel support
- Modern NotificationCompat API
- `FLAG_IMMUTABLE` for PendingIntents
- Material 3 theme
- Cleaner code structure

## Requirements

- Android Studio Hedgehog (2023.1.1) or newer recommended
- JDK 17

## How to build

1. Open this project folder in Android Studio
2. Let Gradle sync finish
3. Connect a device or start an emulator (Android 8.0+)
4. Click **Run** or build APK:
   - **Build → Build Bundle(s) / APK(s) → Build APK(s)**

Debug APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

## Important notes for Android 13+

1. On first launch, the app will ask you to grant **"Display over other apps"** permission. This is required for the overlay.
2. On Android 13+, you may also need to allow notifications.
3. Some manufacturers (Xiaomi, Huawei, Oppo, etc.) have additional battery optimization / auto-start restrictions. You may need to whitelist the app.

## License

Original code Copyright © 2013,2014 Hideyuki SHIMOOKA  
Licensed under the Apache License, Version 2.0

Modernization work is also under Apache License 2.0.
